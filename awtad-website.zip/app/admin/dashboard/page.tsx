import { AdminGuard } from "@/components/admin-guard"
import { AdminNavigation } from "@/components/admin-navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function AdminDashboardPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen bg-background">
        <AdminNavigation />

        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="space-y-8">
            <div className="space-y-2">
              <h1 className="text-3xl font-mono font-bold text-foreground">
                Admin <span className="text-primary">Dashboard</span>
              </h1>
              <p className="text-muted-foreground">Manage your AWTAD website content and projects</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "Total Projects", value: "24", change: "+3 this month" },
                { title: "Active Content", value: "12", change: "Updated today" },
                { title: "Image Gallery", value: "156", change: "+8 new images" },
                { title: "Site Views", value: "2.4k", change: "+12% this week" },
              ].map((stat, index) => (
                <Card key={index} className="bg-card border-border steel-texture">
                  <CardContent className="p-6">
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">{stat.title}</p>
                      <p className="text-2xl font-mono font-bold text-foreground">{stat.value}</p>
                      <p className="text-xs text-primary">{stat.change}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="font-mono">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full justify-start gold-gradient text-primary-foreground hover:opacity-90">
                    Add New Project
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                  >
                    Edit Homepage Content
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                  >
                    Upload Images
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                  >
                    Manage Team Info
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="font-mono">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { action: "Updated project gallery", time: "2 hours ago" },
                    { action: "Added new team member", time: "1 day ago" },
                    { action: "Modified homepage content", time: "3 days ago" },
                    { action: "Uploaded project images", time: "1 week ago" },
                  ].map((activity, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b border-border/50">
                      <span className="text-sm text-foreground">{activity.action}</span>
                      <span className="text-xs text-muted-foreground">{activity.time}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AdminGuard>
  )
}
