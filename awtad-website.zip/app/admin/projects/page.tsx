import { AdminGuard } from "@/components/admin-guard"
import { AdminNavigation } from "@/components/admin-navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function AdminProjectsPage() {
  return (
    <AdminGuard>
      <div className="min-h-screen bg-background">
        <AdminNavigation />

        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-mono font-bold text-foreground">
                Project <span className="text-primary">Management</span>
              </h1>
              <p className="text-muted-foreground">Manage projects and associate images</p>
            </div>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="font-mono">Project Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Advanced project management features are coming soon. For now, you can:
                </p>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Upload project images in the Images section</li>
                  <li>Edit project information in the Content section</li>
                  <li>View project galleries on the public site</li>
                </ul>
                <div className="flex space-x-4">
                  <Button className="gold-gradient text-primary-foreground hover:opacity-90">Go to Images</Button>
                  <Button
                    variant="outline"
                    className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                  >
                    Edit Content
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminGuard>
  )
}
