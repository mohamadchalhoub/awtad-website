"use client"

import { useState, useEffect } from "react"
import { AdminGuard } from "@/components/admin-guard"
import { AdminNavigation } from "@/components/admin-navigation"
import { ImageUpload } from "@/components/image-upload"
import { ImageService, type ImageData } from "@/lib/images"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function AdminImagesPage() {
  const [images, setImages] = useState<ImageData[]>([])
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [deleteMessage, setDeleteMessage] = useState("")

  useEffect(() => {
    loadImages()
  }, [])

  const loadImages = () => {
    const allImages = ImageService.getAllImages()
    setImages(allImages)
  }

  const handleUploadComplete = (image: ImageData) => {
    loadImages()
  }

  const handleDeleteImage = (id: string) => {
    ImageService.deleteImage(id)
    loadImages()
    setDeleteMessage("Image deleted successfully!")
    setTimeout(() => setDeleteMessage(""), 3000)
  }

  const handleClearAll = () => {
    if (confirm("Are you sure you want to delete all images? This action cannot be undone.")) {
      ImageService.clearAllImages()
      loadImages()
      setDeleteMessage("All images cleared!")
      setTimeout(() => setDeleteMessage(""), 3000)
    }
  }

  const filteredImages = selectedCategory === "all" ? images : images.filter((img) => img.category === selectedCategory)

  const categories = ["all", ...new Set(images.map((img) => img.category))]

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <AdminGuard>
      <div className="min-h-screen bg-background">
        <AdminNavigation />

        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <h1 className="text-3xl font-mono font-bold text-foreground">
                  Image <span className="text-primary">Gallery</span>
                </h1>
                <p className="text-muted-foreground">Upload and manage website images</p>
              </div>
              <Button
                variant="outline"
                onClick={handleClearAll}
                className="border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground bg-transparent"
              >
                Clear All Images
              </Button>
            </div>

            {deleteMessage && (
              <Alert className="border-primary/50 bg-primary/10">
                <AlertDescription className="text-primary">{deleteMessage}</AlertDescription>
              </Alert>
            )}

            <Tabs defaultValue="upload">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="upload">Upload Images</TabsTrigger>
                <TabsTrigger value="gallery">Manage Gallery</TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-6">
                <ImageUpload onUploadComplete={handleUploadComplete} />

                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-mono">Upload Statistics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-4 gap-4">
                      <div className="text-center space-y-2">
                        <p className="text-2xl font-mono font-bold text-primary">{images.length}</p>
                        <p className="text-sm text-muted-foreground">Total Images</p>
                      </div>
                      <div className="text-center space-y-2">
                        <p className="text-2xl font-mono font-bold text-primary">
                          {images.filter((img) => img.category === "projects").length}
                        </p>
                        <p className="text-sm text-muted-foreground">Project Images</p>
                      </div>
                      <div className="text-center space-y-2">
                        <p className="text-2xl font-mono font-bold text-primary">
                          {formatFileSize(images.reduce((total, img) => total + img.size, 0))}
                        </p>
                        <p className="text-sm text-muted-foreground">Total Size</p>
                      </div>
                      <div className="text-center space-y-2">
                        <p className="text-2xl font-mono font-bold text-primary">{categories.length - 1}</p>
                        <p className="text-sm text-muted-foreground">Categories</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="gallery" className="space-y-6">
                <div className="flex items-center space-x-4">
                  <label className="text-sm font-medium text-foreground">Filter by category:</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-3 py-2 bg-background border border-border rounded-md text-foreground"
                  >
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>

                {filteredImages.length === 0 ? (
                  <Card className="bg-card border-border">
                    <CardContent className="p-12 text-center">
                      <div className="text-4xl text-muted-foreground mb-4">📷</div>
                      <p className="text-muted-foreground">No images found. Upload some images to get started.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredImages.map((image) => (
                      <Card key={image.id} className="bg-card border-border hover:border-primary/50 transition-colors">
                        <CardContent className="p-0">
                          <div className="aspect-square bg-muted flex items-center justify-center overflow-hidden">
                            <img
                              src={image.url || "/placeholder.svg"}
                              alt={image.name}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          </div>
                          <div className="p-4 space-y-3">
                            <div className="space-y-1">
                              <h3 className="text-sm font-mono font-semibold text-foreground truncate">{image.name}</h3>
                              <p className="text-xs text-primary bg-primary/10 px-2 py-1 rounded w-fit">
                                {image.category}
                              </p>
                            </div>
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>{formatFileSize(image.size)}</span>
                              <span>{new Date(image.uploadDate).toLocaleDateString()}</span>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteImage(image.id)}
                              className="w-full border-destructive/30 text-destructive hover:bg-destructive hover:text-destructive-foreground bg-transparent"
                            >
                              Delete
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AdminGuard>
  )
}
