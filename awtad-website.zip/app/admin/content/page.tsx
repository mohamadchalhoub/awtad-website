"use client"

import { useState } from "react"
import { AdminGuard } from "@/components/admin-guard"
import { AdminNavigation } from "@/components/admin-navigation"
import { useContent } from "@/hooks/use-content"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function AdminContentPage() {
  const { content, updateContent, resetContent } = useContent()
  const [activeTab, setActiveTab] = useState("homepage")
  const [saveMessage, setSaveMessage] = useState("")

  const handleSave = () => {
    setSaveMessage("Content saved successfully!")
    setTimeout(() => setSaveMessage(""), 3000)
  }

  const handleHomepageChange = (field: string, value: any) => {
    const updatedContent = {
      ...content,
      homepage: {
        ...content.homepage,
        [field]: value,
      },
    }
    updateContent(updatedContent)
    handleSave()
  }

  const handleServiceChange = (index: number, field: string, value: string) => {
    const updatedServices = [...content.homepage.services]
    updatedServices[index] = { ...updatedServices[index], [field]: value }

    const updatedContent = {
      ...content,
      homepage: {
        ...content.homepage,
        services: updatedServices,
      },
    }
    updateContent(updatedContent)
    handleSave()
  }

  const handleAboutChange = (field: string, value: any) => {
    const updatedContent = {
      ...content,
      about: {
        ...content.about,
        [field]: value,
      },
    }
    updateContent(updatedContent)
    handleSave()
  }

  const handleTeamMemberChange = (index: number, field: string, value: string) => {
    const updatedTeam = [...content.about.team]
    updatedTeam[index] = { ...updatedTeam[index], [field]: value }

    const updatedContent = {
      ...content,
      about: {
        ...content.about,
        team: updatedTeam,
      },
    }
    updateContent(updatedContent)
    handleSave()
  }

  return (
    <AdminGuard>
      <div className="min-h-screen bg-background">
        <AdminNavigation />

        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <h1 className="text-3xl font-mono font-bold text-foreground">
                  Content <span className="text-primary">Management</span>
                </h1>
                <p className="text-muted-foreground">Edit website content and information</p>
              </div>
              <Button
                variant="outline"
                onClick={resetContent}
                className="border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground bg-transparent"
              >
                Reset to Default
              </Button>
            </div>

            {saveMessage && (
              <Alert className="border-primary/50 bg-primary/10">
                <AlertDescription className="text-primary">{saveMessage}</AlertDescription>
              </Alert>
            )}

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="homepage">Homepage</TabsTrigger>
                <TabsTrigger value="about">About Page</TabsTrigger>
                <TabsTrigger value="projects">Projects</TabsTrigger>
              </TabsList>

              <TabsContent value="homepage" className="space-y-6">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-mono">Hero Section</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Title</label>
                      <Input
                        value={content.homepage?.heroTitle || ""}
                        onChange={(e) => handleHomepageChange("heroTitle", e.target.value)}
                        className="bg-background border-border"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Subtitle</label>
                      <Input
                        value={content.homepage?.heroSubtitle || ""}
                        onChange={(e) => handleHomepageChange("heroSubtitle", e.target.value)}
                        className="bg-background border-border"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Description</label>
                      <Textarea
                        value={content.homepage?.heroDescription || ""}
                        onChange={(e) => handleHomepageChange("heroDescription", e.target.value)}
                        className="bg-background border-border"
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-mono">Services</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {content.homepage?.services?.map((service, index) => (
                      <div key={index} className="p-4 border border-border rounded-lg space-y-4">
                        <h4 className="font-mono font-semibold text-foreground">Service {index + 1}</h4>
                        <div className="grid md:grid-cols-3 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Title</label>
                            <Input
                              value={service.title}
                              onChange={(e) => handleServiceChange(index, "title", e.target.value)}
                              className="bg-background border-border"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Icon</label>
                            <Input
                              value={service.icon}
                              onChange={(e) => handleServiceChange(index, "icon", e.target.value)}
                              className="bg-background border-border"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Description</label>
                            <Textarea
                              value={service.description}
                              onChange={(e) => handleServiceChange(index, "description", e.target.value)}
                              className="bg-background border-border"
                              rows={3}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="about" className="space-y-6">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-mono">Company Story</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {content.about?.story?.map((paragraph, index) => (
                      <div key={index} className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Paragraph {index + 1}</label>
                        <Textarea
                          value={paragraph}
                          onChange={(e) => {
                            const updatedStory = [...content.about.story]
                            updatedStory[index] = e.target.value
                            handleAboutChange("story", updatedStory)
                          }}
                          className="bg-background border-border"
                          rows={4}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-mono">Team Members</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {content.about?.team?.map((member, index) => (
                      <div key={index} className="p-4 border border-border rounded-lg space-y-4">
                        <h4 className="font-mono font-semibold text-foreground">Team Member {index + 1}</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Name</label>
                            <Input
                              value={member.name}
                              onChange={(e) => handleTeamMemberChange(index, "name", e.target.value)}
                              className="bg-background border-border"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Role</label>
                            <Input
                              value={member.role}
                              onChange={(e) => handleTeamMemberChange(index, "role", e.target.value)}
                              className="bg-background border-border"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Experience</label>
                            <Input
                              value={member.experience}
                              onChange={(e) => handleTeamMemberChange(index, "experience", e.target.value)}
                              className="bg-background border-border"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-foreground">Specialty</label>
                            <Input
                              value={member.specialty}
                              onChange={(e) => handleTeamMemberChange(index, "specialty", e.target.value)}
                              className="bg-background border-border"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="projects" className="space-y-6">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-mono">Project Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Project management will be available in the next update. For now, projects are managed through the
                      content system.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AdminGuard>
  )
}
