"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useContent } from "@/hooks/use-content"

export default function AboutPage() {
  const { content, isLoading } = useContent()

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-24 pb-12 px-6">
        <div className="max-w-7xl mx-auto text-center space-y-6">
          <h1 className="text-4xl md:text-5xl font-mono font-bold text-foreground">
            About <span className="text-primary text-shadow-gold">AWTAD</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Leading the future of steel design and engineering with precision, innovation, and unwavering commitment to
            excellence.
          </p>
        </div>
      </section>

      <section className="pb-16 px-6">
        <div className="max-w-4xl mx-auto space-y-12">
          <Card className="bg-card border-border steel-texture">
            <CardContent className="p-8 space-y-6">
              <h2 className="text-2xl font-mono font-bold text-foreground">Our Story</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                {content.about?.story?.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-6">
            {content.about?.values?.map((value, index) => (
              <Card key={index} className="bg-card border-border hover:border-primary/50 transition-colors">
                <CardContent className="p-6 text-center space-y-4">
                  <h3 className="text-lg font-mono font-semibold text-primary">{value.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl md:text-4xl font-mono font-bold text-foreground">
              Our <span className="text-primary">Team</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Expert engineers and designers dedicated to delivering exceptional steel design solutions
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {content.about?.team?.map((member, index) => (
              <Card
                key={index}
                className="bg-card border-border hover:border-primary/50 transition-all hover:glow-gold"
              >
                <CardContent className="p-6 text-center space-y-4">
                  <div className="w-20 h-20 bg-muted steel-texture rounded-full mx-auto flex items-center justify-center">
                    <span className="text-2xl font-mono font-bold text-primary">
                      {member.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </span>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-mono font-semibold text-foreground">{member.name}</h3>
                    <p className="text-sm text-primary font-medium">{member.role}</p>
                    <p className="text-xs text-muted-foreground">
                      {member.experience} • {member.specialty}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-3xl md:text-4xl font-mono font-bold text-foreground">
              Ready to Build <span className="text-primary">Together?</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Let's discuss your steel design and engineering needs. Our team is ready to bring your vision to life with
              precision and excellence.
            </p>
          </div>
          <Button size="lg" className="gold-gradient text-primary-foreground hover:opacity-90 transition-opacity px-8">
            Start Your Project
          </Button>
        </div>
      </section>

      <footer className="py-12 px-6 bg-secondary/50 border-t border-border">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-6 h-6 bg-primary rounded-sm flex items-center justify-center">
              <span className="text-primary-foreground font-mono font-bold text-xs">A</span>
            </div>
            <span className="text-lg font-mono font-bold text-primary">AWTAD</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2024 AWTAD. Advanced Steel Design & Engineering Solutions.</p>
        </div>
      </footer>
    </div>
  )
}
