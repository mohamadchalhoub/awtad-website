import type React from "react"
import type { Metadata } from "next"
import { Inter, Orbitron } from "next/font/google"
import { AuthProvider } from "@/hooks/use-auth"
import { ContentProvider } from "@/hooks/use-content"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const orbitron = Orbitron({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-orbitron",
})

export const metadata: Metadata = {
  title: "AWTAD - Advanced Steel Design & Engineering",
  description:
    "Leading steel design and engineering solutions with cutting-edge technology and precision craftsmanship.",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${orbitron.variable}`}>
      <head>
        <style>{`
html {
  --font-sans: ${inter.style.fontFamily};
  --font-mono: ${orbitron.style.fontFamily};
}
        `}</style>
      </head>
      <body className="antialiased">
        <AuthProvider>
          <ContentProvider>{children}</ContentProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
