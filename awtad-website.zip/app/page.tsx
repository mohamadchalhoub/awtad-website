"use client"

import { Navigation } from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useContent } from "@/hooks/use-content"
import Link from "next/link"

export default function HomePage() {
  const { content, isLoading } = useContent()

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-24 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-7xl font-mono font-bold text-foreground">
                <span className="text-primary text-shadow-gold">{content.homepage?.heroTitle}</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                {content.homepage?.heroSubtitle}
              </p>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{content.homepage?.heroDescription}</p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                size="lg"
                className="gold-gradient text-primary-foreground hover:opacity-90 transition-opacity px-8"
              >
                View Our Projects
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-6 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl md:text-4xl font-mono font-bold text-foreground">
              Our <span className="text-primary">Services</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive steel design solutions for modern industrial challenges
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {content.homepage?.services?.map((service, index) => (
              <Card
                key={index}
                className="bg-card border-border hover:border-primary/50 transition-colors steel-texture"
              >
                <CardContent className="p-8 text-center space-y-4">
                  <div className="text-4xl mb-4">{service.icon}</div>
                  <h3 className="text-xl font-mono font-semibold text-foreground">{service.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl md:text-4xl font-mono font-bold text-foreground">
              Featured <span className="text-primary">Projects</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Showcasing our expertise in steel design and engineering excellence
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {content.homepage?.projects?.map((project) => (
              <Card
                key={project.id}
                className="bg-card border-border hover:border-primary/50 transition-all hover:glow-gold group"
              >
                <CardContent className="p-0">
                  <div className="aspect-video bg-muted steel-texture flex items-center justify-center">
                    <span className="text-muted-foreground font-mono">{project.name}</span>
                  </div>
                  <div className="p-6 space-y-3">
                    <h3 className="text-lg font-mono font-semibold text-foreground group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">{project.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/projects">
              <Button className="gold-gradient text-primary-foreground hover:opacity-90 transition-opacity">
                View All Projects
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <footer className="py-12 px-6 bg-secondary/50 border-t border-border">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-6 h-6 bg-primary rounded-sm flex items-center justify-center">
              <span className="text-primary-foreground font-mono font-bold text-xs">A</span>
            </div>
            <span className="text-lg font-mono font-bold text-primary">AWTAD</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2024 AWTAD. Advanced Steel Design & Engineering Solutions.</p>
        </div>
      </footer>
    </div>
  )
}
