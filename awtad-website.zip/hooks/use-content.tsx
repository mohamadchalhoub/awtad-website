"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { ContentService, type SiteContent } from "@/lib/content"

interface ContentContextType {
  content: SiteContent
  updateContent: (content: SiteContent) => void
  resetContent: () => void
  isLoading: boolean
}

const ContentContext = createContext<ContentContextType | undefined>(undefined)

export function ContentProvider({ children }: { children: ReactNode }) {
  const [content, setContent] = useState<SiteContent>({} as SiteContent)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadedContent = ContentService.getContent()
    setContent(loadedContent)
    setIsLoading(false)
  }, [])

  const updateContent = (newContent: SiteContent) => {
    setContent(newContent)
    ContentService.saveContent(newContent)
  }

  const resetContent = () => {
    ContentService.resetContent()
    const defaultContent = ContentService.getContent()
    setContent(defaultContent)
  }

  return (
    <ContentContext.Provider value={{ content, updateContent, resetContent, isLoading }}>
      {children}
    </ContentContext.Provider>
  )
}

export function useContent() {
  const context = useContext(ContentContext)
  if (context === undefined) {
    throw new Error("useContent must be used within a ContentProvider")
  }
  return context
}
