"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"

export function AdminNavigation() {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  const navItems = [
    { href: "/admin/dashboard", label: "Dashboard" },
    { href: "/admin/content", label: "Content" },
    { href: "/admin/projects", label: "Projects" },
    { href: "/admin/images", label: "Images" },
  ]

  return (
    <nav className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/admin/dashboard" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-sm flex items-center justify-center">
                <span className="text-primary-foreground font-mono font-bold text-sm">A</span>
              </div>
              <span className="text-xl font-mono font-bold text-primary">AWTAD Admin</span>
            </Link>

            <div className="hidden md:flex items-center space-x-6">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`text-sm font-medium transition-colors hover:text-primary ${
                    pathname === item.href ? "text-primary text-shadow-gold" : "text-muted-foreground"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">Welcome, {user?.email}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={logout}
              className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
            >
              Logout
            </Button>
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                View Site
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}
