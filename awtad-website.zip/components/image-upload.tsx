"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { ImageService, type ImageData } from "@/lib/images"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ImageUploadProps {
  onUploadComplete?: (image: ImageData) => void
  defaultCategory?: string
  projectId?: number
}

export function ImageUpload({ onUploadComplete, defaultCategory = "general", projectId }: ImageUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [category, setCategory] = useState(defaultCategory)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const categories = ["general", "projects", "team", "services", "hero"]

  const handleFileUpload = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return

      setIsUploading(true)
      setError("")
      setSuccess("")

      try {
        const file = files[0]
        const imageData = await ImageService.uploadImage(file, category, projectId)

        if (imageData) {
          setSuccess(`Image "${file.name}" uploaded successfully!`)
          onUploadComplete?.(imageData)
        } else {
          setError("Failed to upload image. Please try again.")
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Upload failed")
      } finally {
        setIsUploading(false)
        setTimeout(() => {
          setSuccess("")
          setError("")
        }, 3000)
      }
    },
    [category, projectId, onUploadComplete],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      handleFileUpload(e.dataTransfer.files)
    },
    [handleFileUpload],
  )

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6 space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Category</label>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="bg-background border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging ? "border-primary bg-primary/10" : "border-border hover:border-primary/50 hover:bg-primary/5"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="space-y-4">
            <div className="text-4xl text-muted-foreground">📁</div>
            <div className="space-y-2">
              <p className="text-foreground font-medium">Drop images here or click to browse</p>
              <p className="text-sm text-muted-foreground">Maximum file size: 5MB</p>
            </div>
            <Input
              type="file"
              accept="image/*"
              onChange={(e) => handleFileUpload(e.target.files)}
              className="hidden"
              id="file-upload"
              disabled={isUploading}
            />
            <Button
              variant="outline"
              onClick={() => document.getElementById("file-upload")?.click()}
              disabled={isUploading}
              className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
            >
              {isUploading ? "Uploading..." : "Browse Files"}
            </Button>
          </div>
        </div>

        {error && (
          <Alert className="border-destructive/50 bg-destructive/10">
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-primary/50 bg-primary/10">
            <AlertDescription className="text-primary">{success}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  )
}
